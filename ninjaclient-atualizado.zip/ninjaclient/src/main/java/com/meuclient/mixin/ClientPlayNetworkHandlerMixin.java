package com.meuclient.mixin;

import com.meuclient.MeuClient;
import com.meuclient.modules.NoFall;
import com.meuclient.modules.VaultSniper;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Quando o servidor atualiza uma caixa (vault), os modulos de vault reagem na hora.
 * Tambem e aqui que o NoFall troca o onGround dos pacotes de movimento enviados.
 */
@Mixin(ClientPlayNetworkHandler.class)
public class ClientPlayNetworkHandlerMixin {
    // require = 0: se o metodo mudar de nome, o client abre normal (so perde essa resposta instantanea)
    @Inject(method = "onBlockEntityUpdate", at = @At("TAIL"), require = 0)
    private void ninjaclient$onVaultUpdate(BlockEntityUpdateS2CPacket packet, CallbackInfo ci) {
        VaultSniper.onVaultPacket();
    }

    // require = 0: se o metodo mudar, o NoFall simplesmente nao age (o client abre normal)
    @ModifyVariable(method = "sendPacket(Lnet/minecraft/network/packet/Packet;)V", at = @At("HEAD"),
            argsOnly = true, require = 0)
    private Packet<?> ninjaclient$noFall(Packet<?> packet) {
        if (packet instanceof PlayerMoveC2SPacket move && !move.isOnGround()
                && MeuClient.modules != null
                && MeuClient.modules.get("NoFall") instanceof NoFall noFall
                && noFall.shouldSpoof()) {
            return NoFall.withGround(move);
        }
        return packet;
    }
}
