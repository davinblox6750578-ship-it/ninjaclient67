package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.Module;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

/**
 * AutoTotem: mantem um Totem da Imortalidade na mao secundaria.
 *  - Procura um totem no inventario (hotbar e mochila).
 *  - Se a mao secundaria nao tem totem, troca um para la.
 *  - Se o totem estourar (consumido ao salvar voce), poe outro na hora.
 * Usa o clique de troca (SWAP) direto no inventario do jogador, entao NAO abre
 * o inventario na tela.
 */
public class AutoTotem extends Module {
    private static final int OFFHAND_BUTTON = 40; // botao de troca com a mao secundaria

    public AutoTotem() {
        super("AutoTotem", Category.COMBAT);
        enableToggleKey(-1); // sem tecla padrao: mapeie no menu
    }

    @Override
    public void onTick() {
        // so age com o inventario normal (nao mexe se um bau/outra tela estiver aberta)
        if (mc.player.currentScreenHandler != mc.player.playerScreenHandler) return;

        // ja tem totem na mao secundaria
        if (mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;

        // procura um totem no inventario: indices 0-8 hotbar, 9-35 mochila
        for (int i = 0; i < 36; i++) {
            if (!mc.player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) continue;

            // indice do inventario -> slot da tela do jogador (hotbar = 36-44)
            int slot = i < 9 ? 36 + i : i;
            mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId,
                    slot, OFFHAND_BUTTON, SlotActionType.SWAP, mc.player);
            return; // uma troca por tick
        }
    }
}
