package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.MeuClient;
import com.meuclient.Module;

/**
 * Capa personalizada (so voce ve, e so no seu boneco): capa e elytra com a
 * arte do kanji ninja. Vem LIGADA por padrao; clique no nome no menu para
 * voltar a capa normal.
 *
 * Usa a capa vanilla do jogo, entao a animacao vem de graca: balanca quando
 * voce corre, vai para o lado quando voce anda de lado, e a elytra usa a
 * mesma arte. A textura e fixa (dois arquivos pequenos), sem custo de FPS.
 */
public class Capa extends Module {
    public Capa() {
        super("Capa", Category.MISC);
        enableToggleKey(-1); // sem tecla padrao: mapeie no menu
    }

    @Override
    public boolean defaultEnabled() { return true; }

    /** Usado pelo mixin. */
    public static boolean isActive() {
        if (MeuClient.modules == null) return true;
        Module m = MeuClient.modules.get("Capa");
        return m == null || m.isEnabled();
    }
}
