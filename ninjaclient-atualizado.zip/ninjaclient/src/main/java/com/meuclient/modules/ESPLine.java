package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.Module;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

/**
 * ESPLine: desenha uma linha do centro da tela ate o jogador MAIS PROXIMO,
 * atraves das paredes e a qualquer distancia. Se o jogador estiver atras de
 * voce, a linha aponta para o lado dele, entao voce sabe para onde virar.
 * A linha e recalculada todo frame com a posicao suavizada, entao acompanha
 * o inimigo sem ficar para tras.
 */
public class ESPLine extends Module {
    private static final int LINE = 0xFF00E5FF;
    private static final int GLOW = 0x2200E5FF;
    private static final double NEAR = 0.05;
    private static boolean registered;

    public ESPLine() {
        super("ESPLine", Category.PLAYER);
        enableToggleKey(-1); // sem tecla padrao: mapeie no menu
        if (!registered) {
            registered = true;
            HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                    Identifier.of("ninjaclient", "espline"), (ctx, tickCounter) -> render(ctx));
        }
    }

    private void render(DrawContext ctx) {
        if (!isEnabled() || mc.world == null || mc.player == null) return;

        float delta = mc.getRenderTickCounter().getTickProgress(false);
        Camera cam = mc.gameRenderer.getCamera();
        Vec3d camPos = cam.getPos();

        double yaw = Math.toRadians(cam.getYaw()), pitch = Math.toRadians(cam.getPitch());
        Vec3d fwd = new Vec3d(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
        Vec3d right = new Vec3d(-Math.cos(yaw), 0, -Math.sin(yaw));
        Vec3d up = right.crossProduct(fwd);

        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        double tanHalf = com.meuclient.Projection.tanHalfFov(mc);
        double aspect = (double) sw / sh;
        double cx = sw / 2.0, cy = sh / 2.0;

        // acha so o jogador mais proximo (visivel ou nao, atras de blocos tambem conta)
        PlayerEntity nearest = null;
        double best = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof PlayerEntity p) || p == mc.player || !p.isAlive() || p.isSpectator()) continue;
            double dist = mc.player.distanceTo(p);
            if (dist < best) { best = dist; nearest = p; }
        }

        if (nearest != null) {
            PlayerEntity p = nearest;

            // ponto no meio do corpo do jogador
            Vec3d pos = com.meuclient.PlayerTracker.renderPos(p, delta).add(0, p.getHeight() / 2.0, 0);
            Vec3d d = pos.subtract(camPos);
            double x = d.dotProduct(right), y = d.dotProduct(up), z = d.dotProduct(fwd);
            boolean behind = z < NEAR;
            if (behind) z = NEAR; // atras: mantem so a direcao (lado e altura)

            double ex = cx + (x / z) / (tanHalf * aspect) * (sw / 2.0);
            double ey = cy - (y / z) / tanHalf * (sh / 2.0);
            if (behind) { // empurra o ponto para bem longe na mesma direcao, para a linha sair da tela
                double vx = ex - cx, vy = ey - cy;
                double len = Math.max(1e-6, Math.hypot(vx, vy));
                ex = cx + vx / len * 5000;
                ey = cy + vy / len * 5000;
            }

            drawLine(ctx, cx, cy, ex, ey, sw, sh);
        }
    }

    /** Linha leve (agrupa pixels em retangulos) - ver Draw. */
    private static void drawLine(DrawContext ctx, double x0, double y0, double x1, double y1, int sw, int sh) {
        com.meuclient.Draw.line(ctx, x0, y0, x1, y1, sw, sh, LINE, GLOW);
    }
}
