package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.Module;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Gatilho: voce segura a ancora e a coloca no chao; o modulo carrega (1 glowstone), troca para a
 * ancora e explode em ticks seguidos, SEM esperar o servidor confirmar cada passo.
 * Ele so adota a ancora se voce segurou uma ancora ha pouco (ANCHOR_HELD_MEMORY) e so poe ancora
 * sozinho se AUTO_PLACE_ANCHOR for true. Intervalo entre passos: DELAY_MIN/DELAY_MAX (ticks).
 *
 * AutoAnchor: anchor PvP automatico (Overworld/End, onde a ancora EXPLODE) sem desperdicar
 * ancora nem glowstone. Como os melhores jogadores fazem, e o que o modulo copia:
 *
 *  - O dano da explosao NAO depende da carga (1 carga = 4 cargas, poder 5). Entao o ciclo
 *    certo e: colocar -> carregar com 1 UMA glowstone -> explodir. Nunca poe a 2a glowstone.
 *  - Nunca coloca 2 ancoras: se ja existe uma ancora perto do alvo, usa ela (carregada ou nao).
 *  - So gasta a glowstone quando o alvo esta perto (CHARGE_RADIUS); uma ancora ja carregada
 *    FICA guardada ate o alvo voltar, em vez de explodir no vazio.
 *  - So explode com o alvo dentro do raio da explosao (BLAST_RADIUS).
 *  - Explode com a ANCORA na mao (sem ancora na hotbar, usa qualquer item que nao seja glowstone).
 *    Sem bloco de protecao; REQUIRE_SAFE_EXPLODE=true volta a exigir totem ou 4+ blocos de distancia.
 *  - Espera o servidor confirmar cada passo (carga/ancora aparecendo) antes do proximo,
 *    para nao clicar duas vezes e gastar glowstone/ancora de graca.
 *  - Troca de slot so para a acao e devolve o item que voce segurava.
 */
public class AutoAnchor extends Module {
    private static final double REACH = 4.5;          // alcance para colocar/clicar
    private static final double TARGET_RANGE = 8.0;   // alvo: jogador mais proximo ate aqui
    private static final double CHARGE_RADIUS = 6.0;  // so carrega se o alvo estiver a ate isso da ancora
    private static final double BLAST_RADIUS = 5.0;   // so explode se o alvo estiver a ate isso
    private static final double SAFE_DISTANCE = 4.0;  // sem totem, so explode se voce estiver a isso ou mais
    private static final double MIN_HEALTH = 8.0;     // com menos vida que isso, nao age
    private static final int PENDING_TIMEOUT = 12;    // ticks esperando o servidor confirmar
    private static final int DELAY_MIN = 1, DELAY_MAX = 1; // ticks entre passos; 1 = ticks seguidos (o minimo)
    private static final boolean REQUIRE_SAFE_EXPLODE = false; // true: so explode com totem na mao secundaria ou a 4+ blocos
    private static final boolean AUTO_PLACE_ANCHOR = false; // false: so age na ancora que VOCE colocou
    private static final int ANCHOR_HELD_MEMORY = 60;       // ticks lembrando que voce segurou a ancora
    private static final int PAUSE_AFTER_KILL = 20;

    private enum Pending { NONE, PLACE, CHARGE, EXPLODE }
    private enum Stage { CHARGE, EXPLODE }

    private Pending pending = Pending.NONE;
    private BlockPos pendingPos;
    private int pendingTimer;
    private Stage stage = Stage.CHARGE;
    private BlockPos seqAnchor; // ancora em que a sequencia esta rodando
    private int heldAnchorTicks;
    private int delay;
    private int killPause;
    private PlayerEntity lastTarget;
    private final java.util.Random random = new java.util.Random();

    public AutoAnchor() {
        super("AutoAnchor", Category.COMBAT);
        enableToggleKey(-1); // sem tecla padrao: mapeie no menu
    }

    @Override
    public void onDisable() {
        pending = Pending.NONE;
        pendingPos = null;
        seqAnchor = null;
        stage = Stage.CHARGE;
        heldAnchorTicks = 0;
        pendingTimer = 0;
        delay = 0;
        killPause = 0;
        lastTarget = null;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null || !mc.player.isAlive()) return;

        // so funciona onde a ancora explode (Overworld/End). No Nether ela so carrega/seta spawn.
        if (mc.world.getRegistryKey() == World.NETHER) return;

        if (delay > 0) delay--;
        if (mc.player.getMainHandStack().isOf(Items.RESPAWN_ANCHOR)) heldAnchorTicks = ANCHOR_HELD_MEMORY;
        else if (heldAnchorTicks > 0) heldAnchorTicks--;
        if (mc.player.getHealth() + mc.player.getAbsorptionAmount() < MIN_HEALTH) return;

        if (lastTarget != null && (!lastTarget.isAlive() || lastTarget.isRemoved())) {
            killPause = PAUSE_AFTER_KILL;
            lastTarget = null;
        }
        if (killPause > 0) { killPause--; return; }

        PlayerEntity target = Combat.nearestPlayer(mc, TARGET_RANGE);
        if (target == null) return;
        lastTarget = target;

        // espera a confirmacao do servidor do passo anterior (evita clique duplo = desperdicio)
        if (pending != Pending.NONE && !confirmed()) {
            if (--pendingTimer <= 0) {
                if (pending == Pending.EXPLODE) stage = Stage.CHARGE; // nao confirmou: reavalia carga e explosao
                pending = Pending.NONE; // libera para tentar de novo
            }
            return;
        }
        if (delay > 0) return;

        BlockPos anchor = findAnchor(target);

        if (anchor == null) {
            seqAnchor = null;
            stage = Stage.CHARGE;
            if (AUTO_PLACE_ANCHOR) place(target);
            return;
        }

        int charges = mc.world.getBlockState(anchor).get(RespawnAnchorBlock.CHARGES);
        double targetDist = target.getPos().add(0, target.getHeight() / 2.0, 0).distanceTo(Vec3d.ofCenter(anchor));

        // ancora nova: so adota se voce acabou de segurar uma ancora (ou se o auto-place esta ligado)
        if (!anchor.equals(seqAnchor)) {
            if (heldAnchorTicks == 0 && !AUTO_PLACE_ANCHOR) return;
            seqAnchor = anchor;
            stage = charges == 0 ? Stage.CHARGE : Stage.EXPLODE;
        }

        switch (stage) {
            case CHARGE -> {
                if (targetDist > CHARGE_RADIUS) return; // alvo longe: nao gasta glowstone
                if (charges > 0 || charge(anchor)) stage = Stage.EXPLODE;
            }
            case EXPLODE -> {
                if (targetDist > BLAST_RADIUS) return;
                if (REQUIRE_SAFE_EXPLODE && !safeToExplode(anchor)) return;
                explode(anchor);
            }
        }
    }

    // ---------------------------------------------------------------- acoes

    private void place(PlayerEntity target) {
        int slot = findSlot(Items.RESPAWN_ANCHOR);
        if (slot == -1) return;
        BlockPos base = findBase(target);
        if (base == null) return;

        click(slot, base, Direction.UP);
        pending = Pending.PLACE;
        pendingPos = base.up();
        pendingTimer = PENDING_TIMEOUT;
        delay = randomDelay();
    }

    private boolean charge(BlockPos anchor) {
        int slot = findSlot(Items.GLOWSTONE);
        if (slot == -1) return false;
        // UMA glowstone: a explosao tem o mesmo poder com 1 ou 4 cargas
        click(slot, anchor, bestFace(anchor));
        delay = randomDelay();
        return true;
    }

    private void explode(BlockPos anchor) {
        int slot = findSlot(Items.RESPAWN_ANCHOR); // troca para a ancora; sem ela, outro item que nao seja glowstone
        if (slot == -1) slot = findNonGlowstoneSlot();
        if (slot == -1) return;
        click(slot, anchor, bestFace(anchor));
        pending = Pending.EXPLODE;
        pendingPos = anchor;
        pendingTimer = PENDING_TIMEOUT;
        delay = randomDelay();
    }

    /** Troca para o slot, interage e devolve o item que estava na mao. */
    private void click(int slot, BlockPos on, Direction face) {
        int previous = mc.player.getInventory().getSelectedSlot();
        if (previous != slot) mc.player.getInventory().setSelectedSlot(slot);

        Vec3d hit = Vec3d.ofCenter(on).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(hit, face, on, false));
        mc.player.swingHand(Hand.MAIN_HAND);

        if (previous != slot) mc.player.getInventory().setSelectedSlot(previous);
    }

    // ------------------------------------------------------- confirmacao

    private boolean confirmed() {
        BlockState st = mc.world.getBlockState(pendingPos);
        return switch (pending) {
            case PLACE -> st.isOf(Blocks.RESPAWN_ANCHOR);
            case CHARGE -> st.isOf(Blocks.RESPAWN_ANCHOR) && st.get(RespawnAnchorBlock.CHARGES) > 0;
            case EXPLODE -> !st.isOf(Blocks.RESPAWN_ANCHOR);
            case NONE -> true;
        };
    }

    private boolean safeToExplode(BlockPos anchor) {
        if (mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return true;
        return mc.player.getEyePos().distanceTo(Vec3d.ofCenter(anchor)) >= SAFE_DISTANCE;
    }

    // ------------------------------------------------------------ busca

    /** Ancora ja existente perto do alvo e ao seu alcance (reaproveita, nunca poe outra). */
    private BlockPos findAnchor(PlayerEntity target) {
        BlockPos t = target.getBlockPos();
        Vec3d eye = mc.player.getEyePos();
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        for (int dx = -5; dx <= 5; dx++) {
            for (int dy = -4; dy <= 4; dy++) {
                for (int dz = -5; dz <= 5; dz++) {
                    BlockPos p = t.add(dx, dy, dz);
                    if (!mc.world.getBlockState(p).isOf(Blocks.RESPAWN_ANCHOR)) continue;
                    if (eye.distanceTo(Vec3d.ofCenter(p)) > REACH) continue;
                    double d = target.getPos().distanceTo(Vec3d.ofCenter(p));
                    if (d < bestDist) { bestDist = d; best = p; }
                }
            }
        }
        return best;
    }

    /** Bloco solido perto do alvo, com espaco livre em cima, ao alcance e nao atras de voce. */
    private BlockPos findBase(PlayerEntity target) {
        BlockPos t = target.getBlockPos();
        Vec3d eye = mc.player.getEyePos();
        double yawRad = Math.toRadians(mc.player.getYaw());
        double lookX = -Math.sin(yawRad), lookZ = Math.cos(yawRad);
        BlockPos best = null;
        double bestScore = Double.MAX_VALUE;

        for (int dx = -3; dx <= 3; dx++) {
            for (int dy = -2; dy <= 1; dy++) {
                for (int dz = -3; dz <= 3; dz++) {
                    BlockPos p = t.add(dx, dy, dz);
                    BlockState base = mc.world.getBlockState(p);
                    if (!base.isSolidBlock(mc.world, p)) continue;
                    BlockPos spot = p.up();
                    if (!mc.world.getBlockState(spot).isReplaceable()) continue;
                    if (!mc.world.getOtherEntities(null, new Box(spot)).isEmpty()) continue; // nao em cima de ninguem

                    Vec3d center = Vec3d.ofCenter(spot);
                    if (eye.distanceTo(Vec3d.ofCenter(p).add(0, 0.5, 0)) > REACH) continue;

                    double toX = center.x - mc.player.getX(), toZ = center.z - mc.player.getZ();
                    double hLen = Math.hypot(toX, toZ);
                    if (hLen > 0.8 && (toX * lookX + toZ * lookZ) / hLen < -0.1) continue; // atras de voce

                    // quanto mais perto do alvo, maior o dano; um pouco de distancia de voce e melhor
                    double score = target.getPos().add(0, 0.9, 0).distanceTo(center)
                            - Math.min(1.5, eye.distanceTo(center)) * 0.2;
                    if (score < bestScore) { bestScore = score; best = p; }
                }
            }
        }
        return best;
    }

    /** Face da ancora voltada para voce. */
    private Direction bestFace(BlockPos pos) {
        Vec3d d = mc.player.getEyePos().subtract(Vec3d.ofCenter(pos));
        return Direction.getFacing(d.x, d.y, d.z);
    }

    private int findSlot(Item item) {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isOf(item)) return i;
        }
        return -1;
    }

    /** Slot para explodir: qualquer item que NAO seja glowstone (prefere o que ja esta na mao). */
    private int findNonGlowstoneSlot() {
        int sel = mc.player.getInventory().getSelectedSlot();
        if (!mc.player.getInventory().getStack(sel).isOf(Items.GLOWSTONE)) return sel;
        for (int i = 0; i < 9; i++) {
            if (!mc.player.getInventory().getStack(i).isOf(Items.GLOWSTONE)) return i;
        }
        return -1;
    }

    private int randomDelay() {
        return DELAY_MIN + random.nextInt(DELAY_MAX - DELAY_MIN + 1);
    }
}
