package com.meuclient;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Properties;

/**
 * Salva e carrega tudo que voce configurou: cores do menu, quais modulos
 * estao ligados, as teclas mapeadas e opcoes extras (ex.: parte do corpo do
 * AimAssist). Arquivo: .minecraft/config/ninjaclient.properties
 * Salva sozinho pouco depois de cada mudanca e ao fechar o jogo.
 */
public final class Config {
    private Config() {}

    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("ninjaclient.properties");
    private static boolean dirty;
    private static int ticksSinceChange;

    public static void markDirty() {
        dirty = true;
        ticksSinceChange = 0;
    }

    /** Chamado todo tick: salva 2 segundos depois da ultima mudanca. */
    public static void tick() {
        if (dirty && ++ticksSinceChange >= 40) save();
    }

    public static void save() {
        if (MeuClient.modules == null) return;
        Properties p = new Properties();
        p.setProperty("theme.background", Integer.toHexString(Theme.background));
        p.setProperty("theme.enabled", Integer.toHexString(Theme.enabled));
        p.setProperty("theme.header", Integer.toHexString(Theme.header));

        for (Module m : MeuClient.modules.modules) {
            if (m.isSettings()) continue;
            p.setProperty("module." + m.name + ".enabled", String.valueOf(m.isEnabled()));
            if (m.hasKey()) p.setProperty("module." + m.name + ".key", String.valueOf(m.getKey()));
            String extra = m.getExtra();
            if (extra != null) p.setProperty("module." + m.name + ".extra", extra);
        }

        try (Writer w = Files.newBufferedWriter(FILE)) {
            p.store(w, "NinjaClient");
            dirty = false;
            ticksSinceChange = 0;
        } catch (IOException e) {
            System.err.println("[NinjaClient] Nao foi possivel salvar a config: " + e.getMessage());
        }
    }

    public static void load(List<Module> modules) {
        Properties p = new Properties();
        if (Files.exists(FILE)) {
            try (Reader r = Files.newBufferedReader(FILE)) {
                p.load(r);
            } catch (IOException e) {
                System.err.println("[NinjaClient] Nao foi possivel ler a config: " + e.getMessage());
                return;
            }
        }

        Theme.background = color(p, "theme.background", Theme.background);
        Theme.enabled = color(p, "theme.enabled", Theme.enabled);
        Theme.header = color(p, "theme.header", Theme.header);

        for (Module m : modules) {
            if (m.isSettings()) continue;
            String key = p.getProperty("module." + m.name + ".key");
            if (key != null && m.hasKey()) {
                try { m.setKey(Integer.parseInt(key.trim())); } catch (NumberFormatException ignored) {}
            }
            String extra = p.getProperty("module." + m.name + ".extra");
            if (extra != null) m.setExtra(extra);
            boolean on = Boolean.parseBoolean(
                    p.getProperty("module." + m.name + ".enabled", String.valueOf(m.defaultEnabled())));
            m.loadEnabled(on);
        }
    }

    private static int color(Properties p, String name, int fallback) {
        String v = p.getProperty(name);
        if (v == null) return fallback;
        try { return (int) Long.parseLong(v.trim(), 16); } catch (NumberFormatException e) { return fallback; }
    }
}
